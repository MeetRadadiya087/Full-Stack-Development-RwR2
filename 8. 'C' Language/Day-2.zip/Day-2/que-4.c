// Write a Program to find Simple interest.





#include<stdio.h>
main(){
    int l = 10;
    int w = 20;

    printf("Area Of Rectangle %d",l*w);
}



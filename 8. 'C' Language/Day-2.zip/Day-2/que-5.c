// Write a Program to find the area of a square.


#include<stdio.h>
main(){
 
 int p = 10000;
 int r = 10;
 int t = 12;

 printf("%d", p * r * t / 100);
}




// Write a Program to find the area of a square.

#include<stdio.h>

int main(){

int a = 10;

printf("Area Of Square %d",a*a);

}

// Write a Program to find the perimeter of a triangle.



#include<stdio.h>

main(){

    int a = 10;
    int b = 20;
    int c = 15;
    printf("Area Of Triangle %d", a + b + c );
    
}



